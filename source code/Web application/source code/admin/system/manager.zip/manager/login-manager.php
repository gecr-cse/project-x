<?php
class loginManager extends Application{

    function checkExistence($username){
        echo
        $sql="SELECT * FROM `user_login` WHERE `user_name`='$username' AND `user_login`.`is_active`='yes'";
        return $this->executeQuery($sql);
    }

    function updatePassword($user_id,$pass1){
        $sql="UPDATE `user_login` SET `user_pass` = '$pass1' WHERE `user_login`.`user_id` = $user_id";
        return $this->updateQuery($sql);
    }
}
?>