<?php
class feedbackManager extends Application
{
    function addFeedback($student_id,$dept_id,$feedback_title,$feedback_description)
	{
        //echo
        $sql="INSERT INTO `feedback` (`dept_id`, `student_id`, `feedback_title`, `feedback_desc`, `is_active`, `added_on`) VALUES ('$dept_id', '$student_id', '$feedback_title', '$feedback_description', 'yes', CURRENT_TIMESTAMP)";
        return $this->updateQuery($sql);
    }
	function getFeedbackByStudent($student_id)
	{
        $sql="SELECT * FROM `feedback` WHERE `feedback`.`student_id`='$student_id'";
        return $this->executeQuery($sql);	
    }
	function getAllFeedback()
	{
        $sql="SELECT * FROM `feedback` ";
        return $this->executeQuery($sql);	
    }
}
?>