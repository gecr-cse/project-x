<?php

include_once "../library/application.php";
include_once "../plugins/messages/class.messages.php";
include_once "../plugins/mails/mail.php";
include_once "../manager/feedback-manager.php";


$feedback=new feedbackController();
switch($_REQUEST['action'])
{
    case 'addFeedback':$feedback->addFeedback();break;


}

class feedbackController
{
    function __construct()
    {
        $this->msg = new Messages();
        $this->mail = new Mail();
        $this->common = new Common();
        $this->feedback=new feedbackManager();
    }

    function addFeedback(){
        $student_id=$_REQUEST['student_id'];
        $dept_id=$_REQUEST['dept_id'];
        $feedback_title=$_REQUEST['feedback_title'];
        $feedback_description=$_REQUEST['feedback_description'];
        //$iamges=$_REQUEST['issue_image'];
        $iamges="images";
        $result=$this->feedback->addFeedback($student_id,$dept_id,$feedback_title,$feedback_description);
        if($result)
            $this->msg->add("s","Issue Submitted Successfully");
        else
            $this->msg->add("s","Issue submit failed...Please try again later");
        header("Location:".BASE_URL."feedback.php");
    }


}